//
//  ViewController.swift
//  billsplit
//
//  Created by user226769 on 9/30/22.
//

import UIKit
var tipValue: Int = 0
var totalPeople: Int = 0
var totalAmount: Int = 0
class ViewController: UIViewController {
    //input field for total number of people
    @IBOutlet weak var numPeople: UITextField!
    
    // input field fir bill amount
    @IBOutlet weak var billAmount: UITextField!
    
    // final amount for each person here I consider only int value rather double
    var finalAmount = "0"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    //tip
    //0
    @IBAction func zeroTip(_ sender: UIButton) {
        tipValue = 0
    }
    //10
    @IBAction func temTip(_ sender: UIButton) {
        tipValue = 10
    }
    //20
    @IBAction func twentyTip(_ sender: UIButton) {
        tipValue = 20
    }
    // adding persons
    @IBAction func plus_(_ sender: UIButton) {
        totalPeople += 1
        numPeople.text = "\(totalPeople)"
    }
    // removing persons
    @IBAction func minus_(_ sender: UIButton) {
        if totalPeople != 0{
            totalPeople -= 1
        }
        numPeople.text = "\(totalPeople)"
    }

    @IBAction func calculatePressed(_ sender: UIButton) {
        // adding tip amount and bill amount
        totalAmount = tipValue + Int(billAmount.text!)!
        // amount calculating for each person
        if totalPeople > 0{
            finalAmount = String(totalAmount / totalPeople)
        }
        performSegue(withIdentifier: "goToResult", sender: self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "goToResult" {
            let destinationVC = segue.destination as! SecViewController
            destinationVC.result = self.finalAmount
        }
    }
}


