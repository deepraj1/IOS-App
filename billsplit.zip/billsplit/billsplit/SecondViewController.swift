//
//  SecondViewController.swift
//  billsplit
//
//  Created by user226769 on 9/30/22.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .red

        // Do any additional setup after loading the view.
    }
    

    

}
